const pages = {
  workouts: {
    title: "Выбери свою тренировку",
    intro: "Разные направления — одна цель: стать сильнее.",
    items: [
      {icon:"🏋️",name:"Силовая",tag:"45–60 минут",desc:"Базовые упражнения для развития силы и мышц."},
      {icon:"⚡",name:"Функциональная",tag:"40 минут",desc:"Динамичная тренировка на выносливость и координацию."},
      {icon:"🧘",name:"Мобильность",tag:"30 минут",desc:"Мягкая работа над гибкостью и подвижностью."}
    ]
  },
  coaches: {
    title: "Команда тренеров",
    intro: "Тренеры помогут подобрать нагрузку под твои цели.",
    items: [
      {icon:"👤",name:"Алексей Морозов",tag:"Силовая подготовка",desc:"Помогает освоить технику базовых упражнений."},
      {icon:"👤",name:"Диана Садыкова",tag:"Функциональный тренинг",desc:"Составляет динамичные программы для любого уровня."},
      {icon:"👤",name:"Илья Ким",tag:"Мобильность",desc:"Работает над осанкой, гибкостью и контролем движения."}
    ]
  },
  plans: {
    title: "Абонементы",
    intro: "Выбери формат, который подходит твоему расписанию.",
    items: [
      {icon:"🌱",name:"Старт",tag:"На 1 месяц",price:"15 000 ₸",desc:"Доступ в тренажёрный зал в дневные часы."},
      {icon:"🔥",name:"Стандарт",tag:"На 1 месяц",price:"22 000 ₸",desc:"Полный доступ в зал и групповые занятия."},
      {icon:"👑",name:"Премиум",tag:"На 3 месяца",price:"58 000 ₸",desc:"Полный доступ и одна вводная консультация."}
    ]
  }
};

const content = document.querySelector("#content");
const tabs = [...document.querySelectorAll("[data-page]")];

function renderPage(pageKey) {
  const page = pages[pageKey];
  if (!page) {
    content.textContent = "Не удалось открыть раздел. Попробуйте ещё раз.";
    return;
  }
  content.replaceChildren();
  const heading = document.createElement("div");
  heading.className = "section-head";
  const copy = document.createElement("div");
  const title = document.createElement("h2");
  title.textContent = page.title;
  const intro = document.createElement("p");
  intro.className = "muted";
  intro.textContent = page.intro;
  copy.append(title, intro);
  heading.append(copy);
  content.append(heading);

  const grid = document.createElement("div");
  grid.className = "grid";
  page.items.forEach(item => {
    const card = document.createElement("article");
    card.className = "card";
    const icon = document.createElement("div");
    icon.className = "symbol";
    icon.textContent = item.icon;
    const name = document.createElement("h3");
    name.textContent = item.name;
    const tag = document.createElement("span");
    tag.className = "pill";
    tag.textContent = item.tag;
    const desc = document.createElement("p");
    desc.textContent = item.desc;
    card.append(icon, name, tag);
    if (item.price) {
      const price = document.createElement("div");
      price.className = "price";
      price.textContent = item.price;
      card.append(price);
    }
    card.append(desc);
    grid.append(card);
  });
  content.append(grid);
  tabs.forEach(tab => {
    const active = tab.dataset.page === pageKey;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
    tab.tabIndex = active ? 0 : -1;
  });
}

tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => renderPage(tab.dataset.page));
  tab.addEventListener("keydown", event => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    event.preventDefault();
    const direction = event.key === "ArrowRight" ? 1 : -1;
    const next = tabs[(index + direction + tabs.length) % tabs.length];
    next.focus();
    renderPage(next.dataset.page);
  });
});
renderPage("workouts");
